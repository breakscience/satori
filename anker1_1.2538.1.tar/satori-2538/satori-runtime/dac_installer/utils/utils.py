import sys
import logging
import time
import subprocess

status_code = 0


def get_logger():
    logger = logging.getLogger("satori")
    logger.setLevel(logging.DEBUG)
    if not logger.hasHandlers():
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(
            logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        )
        logger.addHandler(ch)
    return logger


logger = get_logger()


def run_cmd(
    command,
    can_fail=False,
    input=None,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    failure_cb=None,
    failure_cb_arg=None,
):
    global status_code
    if not isinstance(command, list):
        command = command.split(" ")
    res = subprocess.run(command, stdout=stdout, stderr=stderr, input=input)

    if res.returncode != 0:
        # If the out streams are console, decode them to string for printing to the log
        if stdout == subprocess.PIPE:
            stdout = res.stdout.decode("utf-8")
        if stderr == subprocess.PIPE:
            stderr = res.stderr.decode("utf-8")
        if failure_cb != None:
            failure_cb(failure_cb_arg)
        if can_fail:
            logger.debug(
                "Command '%s' returned %d, exiting:\n%s\n%s",
                " ".join(command),
                res.returncode,
                stdout,
                stderr,
            )
        else:
            logger.error(
                "Command '%s' returned %d, exiting:\n%s\n%s",
                " ".join(command),
                res.returncode,
                stdout,
                stderr,
            )
            status_code = res.returncode
            sys.exit(status_code)
    else:
        logger.debug(
            "Command '%s' finished can_fail=%s rc=%d:",
            " ".join(command),
            can_fail,
            res.returncode,
        )

    return res
