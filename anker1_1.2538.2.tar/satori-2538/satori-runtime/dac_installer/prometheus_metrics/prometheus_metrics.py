import os
from typing import NamedTuple, Optional
from prometheus_client.parser import text_string_to_metric_families
from prometheus_client import Gauge, CollectorRegistry, generate_latest
import redis
from utils.utils import get_logger
from utils.redis_ha import get_redis_ha


logger = get_logger()


class Metric(NamedTuple):
    counter: Gauge
    incremental: bool


class Counters(NamedTuple):
    sm_version: Metric
    sm_latest_version: Metric
    sm_update_time: Metric
    sm_gcp_error: Metric
    sm_update_failure: Metric
    sm_last_run: Metric
    sm_num_restarts: Metric


class Metrics:
    def __init__(self, _namespace: str, use_redis: bool):
        self.registry = CollectorRegistry()
        self.metrics = Counters(
            sm_version=Metric(
                Gauge("sm_version", "", ["secret_id"], registry=self.registry), False
            ),
            sm_latest_version=Metric(
                Gauge("sm_latest_version", "", ["secret_id"], registry=self.registry),
                False,
            ),
            sm_update_time=Metric(
                Gauge("sm_update_time", "", ["secret_id"], registry=self.registry),
                False,
            ),
            sm_gcp_error=Metric(
                Gauge("sm_gcp_error", "", ["type"], registry=self.registry), True
            ),
            sm_update_failure=Metric(
                Gauge("sm_update_failure", "", ["secret_id"], registry=self.registry),
                True,
            ),
            sm_last_run=Metric(
                Gauge("sm_last_run", "", ["status"], registry=self.registry), False
            ),
            sm_num_restarts=Metric(
                Gauge("sm_num_restarts", "", ["name"], registry=self.registry), True
            ),
        )
        self.redis_instance = None
        try:
            if use_redis:
                self.redis_metrics_key: str = os.environ.get(
                    "SM_METRICS_REDIS_KEY", "sm_metrics"
                )
                self.redis_instance = get_redis_ha(logger)
                self.load_previous_metrics()
        except Exception as e:  # pylint: disable=broad-except
            logger.warning(
                f"Fail to connect to redis, error {e}, metrics will not be saved to redis"
            )
            self.redis_instance = None

    @staticmethod
    def get_from_redis_with_retry(
        key: str, retires: int, redis: redis.Redis
    ) -> Optional[str]:
        counter = 0
        while counter <= retires:
            try:
                return redis.get(key)
            except Exception as e:
                if counter < retires:
                    counter += 1
        return None

    def load_previous_metrics(self):
        """some metrics are should be incremental, here we load their value from previous run"""
        try:
            prev_metrics = Metrics.get_from_redis_with_retry(
                self.redis_metrics_key, 3, self.redis_instance
            )
            if prev_metrics != None:
                logger.info(prev_metrics)
                for prev_metric in text_string_to_metric_families(
                    prev_metrics.decode("utf-8")
                ):
                    metric: Metric = getattr(self.metrics, prev_metric.name)
                    if metric != None and metric.incremental:
                        for sample in prev_metric.samples:
                            logger.info(
                                f"Metric {prev_metric.name} {list(sample.labels.values())} =>  {sample.value}"
                            )
                            if sample.labels.values():
                                metric.counter.labels(*sample.labels.values()).set(
                                    sample.value
                                )
                            else:
                                metric.counter.set(sample.value)
        except Exception as e:
            logger.warning(f"Fail to load previous metrics, error {e}")

    def write_metrics_to_redis(self):
        try:
            if self.redis_instance != None:
                metrics_txt = generate_latest(self.registry)
                logger.info(f"Update metrics\n:{metrics_txt}")
                self.redis_instance.set(self.redis_metrics_key, metrics_txt)
        except Exception as e:
            logger.warning(f"Fail to write metrics to redis, error {e}")

    @property
    def versions(self) -> Gauge:
        return self.metrics.sm_version.counter

    @property
    def latest_versions(self) -> Gauge:
        return self.metrics.sm_latest_version.counter

    @property
    def update_time(self) -> Gauge:
        return self.metrics.sm_update_time.counter

    @property
    def gcp_errors(self) -> Gauge:
        return self.metrics.sm_gcp_error.counter

    @property
    def last_run(self) -> Gauge:
        return self.metrics.sm_last_run.counter

    @property
    def num_restarts(self) -> Gauge:
        return self.metrics.sm_num_restarts.counter

    @property
    def update_failure(self) -> Gauge:
        return self.metrics.sm_update_failure.counter
