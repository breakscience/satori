from __future__ import annotations
import argparse
import base64
from distutils.util import strtobool
import json
import os
import shutil
import subprocess
import tarfile
import tempfile
import time
import atexit
from datetime import datetime
from google.cloud import secretmanager
from utils.utils import get_logger, run_cmd, status_code
from prometheus_metrics.prometheus_metrics import Metrics
from gcp_access.gcp_access import GCPErrors, GoogleAccess


logger = get_logger()

DAC_INSTALLER_SECRET_PATH = "/satori_tmp/"
K8S_NAMESPACE = os.environ.get("POD_NAMESPACE", "satori-runtime")


satori_deployer: SatoriDeployer = None


class SatoriDeployer:
    def __init__(self, args, secret_rotation: bool):
        self.namespace = K8S_NAMESPACE
        self.dac_installer = getattr(args, "dac_installer", True)
        self.no_client_tls = bool(strtobool(os.environ.get("NO_CLIENT_TLS", "false")))
        self.secret_rotation = secret_rotation
        self.metrics = Metrics(self.namespace, secret_rotation)
        self.updated_secrets = set()
        self.gcp_access = GoogleAccess(args, self.namespace, self.metrics)
        self.backup_gcp_sa_secret(force=False)

    def secret_used_by_resource(self, resource_type, resource_name):
        secret_names = []
        logger.info(
            "checking if %s %s should be restarted " % (resource_type, resource_name)
        )

        # list all secrets that are used by this resource as volumes
        secret_volumes: subprocess.CompletedProcess = run_cmd(
            "kubectl get %s %s -n %s -o jsonpath='{.spec.template.spec.volumes[*].secret.secretName}'"
            % (resource_type, resource_name, self.namespace)
        )
        if secret_volumes.returncode == 0:
            secret_names = (
                secret_volumes.stdout.decode("UTF-8").strip(" \"'\t\r\n").split()
            )

        # list all secrets that are used by this resource as ENV variable
        secret_env: subprocess.CompletedProcess = run_cmd(
            "kubectl get %s %s -n %s -o jsonpath='{.spec.template.spec.containers[0].env[?(@.valueFrom.secretKeyRef.name)].valueFrom.secretKeyRef.name}'"
            % (resource_type, resource_name, self.namespace)
        )
        if secret_env.returncode == 0:
            secret_names.extend(
                secret_env.stdout.decode("UTF-8").strip(" \"'\t\r\n").split()
            )

        # check id one of the secrets that are used by this resource was updated
        for secret_name in secret_names:
            if secret_name in self.updated_secrets:
                logger.info("new version of secret %s was found" % secret_name)
                return True
            else:
                logger.info("secret %s wasn't updated" % secret_name)

        logger.info("No need to restart %s %s" % (resource_type, resource_name))

    def download_secret_to_file(self, secret_id, filename):
        version, payload = self.gcp_access.download_secret(secret_id)
        with open(filename, "w") as secret_file:
            secret_file.write(payload)
        return version

    def delete_secret(self, secret_id):
        run_cmd("kubectl delete secret %s -n %s" % (secret_id, self.namespace), True)

    def get_secret_current_veriosn(self, secret_id):
        curr_version = 0
        response: subprocess.CompletedProcess = run_cmd(
            "kubectl get secret %s -n %s -o json" % (secret_id, self.namespace),
            can_fail=True,
        )
        if response.returncode == 0:
            secret_info = json.loads(response.stdout)
            curr_version = (
                secret_info.get("metadata", {}).get("annotations", {}).get("version", 0)
            )
            logger.debug("current secret %s version is %s" % (secret_id, curr_version))
        return curr_version

    def should_update_secret(self, secret_id, latest_version):
        if self.secret_rotation:
            try:
                curr_version = self.get_secret_current_veriosn(secret_id)
                update_secret = curr_version == 0 or curr_version != latest_version
                logger.info(
                    "{} to update secret {}: {} -> {}".format(
                        "Going to" if update_secret else "No need",
                        secret_id,
                        curr_version,
                        latest_version,
                    )
                )
                if update_secret:
                    self.updated_secrets.add(secret_id)
                return update_secret
            except Exception as e:
                logger.error(f"Fail to read secret {secret_id} version, error {e}")
        self.updated_secrets.add(secret_id)
        return True

    def annotate_secret(
        self, secret_id: str, annotation_name: str, annotation_value: str
    ):
        run_cmd(
            "kubectl annotate secret %s --overwrite %s=%s -n %s"
            % (secret_id, annotation_name, annotation_value, self.namespace)
        )

    def get_secret_last_update_time(self, secret_id: str):
        try:
            cmd = f"kubectl get secret {secret_id} --namespace {self.namespace} --show-managed-fields -o json"
            response: subprocess.CompletedProcess = run_cmd(cmd, can_fail=True)
            if response.returncode == 0:
                secret_info = json.loads(response.stdout)
                dates = [entry['time'] for entry in secret_info['metadata']['managedFields']]
                timestamps = [datetime.strptime(time, "%Y-%m-%dT%H:%M:%SZ") for time in dates]
                last_update_time = sorted(timestamps, reverse=True)[0]
                logger.info("secret %s was last updated in %s" % (secret_id, last_update_time.strftime("%Y-%m-%dT%H:%M:%SZ")))
                return last_update_time.timestamp()
        except Exception as e:
            logger.error(f"failed to get secret {secret_id} last update time")
        return 0

    def on_update_secret_failure(secret_id):
        satori_deployer.metrics.update_failure.labels(secret_id).inc()

    def update_secret_metrics(self, secret_id, latest_version):
        self.metrics.latest_versions.labels(secret_id=secret_id).set(latest_version)
        self.metrics.versions.labels(secret_id=secret_id).set(
            self.get_secret_current_veriosn(secret_id)
        )
        self.metrics.update_time.labels(secret_id=secret_id).set(
            self.get_secret_last_update_time(secret_id)
        )


    def populate_secret_file(self, secret_id, dst_filename):
        src_filename = ""
        # always update during installation
        if self.dac_installer:
            src_filename = DAC_INSTALLER_SECRET_PATH
        src_filename += "%s.secret" % secret_id
        latest_version = self.download_secret_to_file(secret_id, src_filename)
        if self.should_update_secret(secret_id, latest_version):
            response: subprocess.CompletedProcess = run_cmd(
                "kubectl create secret generic %s --save-config --dry-run=client --from-file=%s=%s -n %s -o yaml"
                % (secret_id, dst_filename, src_filename, self.namespace),
                failure_cb=SatoriDeployer.on_update_secret_failure,
                failure_cb_arg=secret_id,
            )
            if response.returncode == 0:
                run_cmd(
                    "kubectl apply -f -",
                    input=response.stdout,
                    failure_cb=SatoriDeployer.on_update_secret_failure,
                    failure_cb_arg=secret_id,
                )
                self.annotate_secret(secret_id, "version", latest_version)
        os.remove(src_filename)
        self.update_secret_metrics(secret_id, latest_version)

    def backup_gcp_sa_secret(self, force=True):
        """
        create a backup secert for dac-gcp-sa before rotation
        from self.env.gcp_sa_info which is the latest working service account
        """
        try:
            if force:
                logger.info("backup dac-gcp-sa")
                response: subprocess.CompletedProcess = run_cmd(
                    [
                        "kubectl",
                        "create",
                        "secret",
                        "generic",
                        "dac-gcp-sa-previous",
                        f"--from-literal=dac-gcp-sa={json.dumps(self.gcp_access.gcp_sa_info)}",
                        "-n",
                        self.namespace,
                        "--save-config",
                        "--dry-run=client",
                        "-o",
                        "yaml",
                    ]
                )
                if response.returncode == 0:
                    run_cmd("kubectl apply -f -", input=response.stdout, can_fail=True)
                    logger.info("dac-gcp-sa-previous was created successfully")
            else:
                # don't overwrite if exists
                response: subprocess.CompletedProcess = run_cmd(
                    [
                        "kubectl",
                        "create",
                        "secret",
                        "generic",
                        "dac-gcp-sa-previous",
                        f"--from-literal=dac-gcp-sa={json.dumps(self.gcp_access.gcp_sa_info)}",
                        "-n",
                        self.namespace,
                    ],
                    can_fail=True,
                )

        except Exception as e:
            logger.error(f"Fail to backup gcp service account secret, error {e}")

    def populate_gcp_sa_secret(self):
        src_filename = ""
        if self.dac_installer:
            src_filename = DAC_INSTALLER_SECRET_PATH
        src_filename += "dac-gcp-sa.secret"
        latest_version = self.download_secret_to_file("dac-secrets-sa", src_filename)
        if self.should_update_secret("dac-gcp-sa", latest_version):
            # save backup before rotating the secret
            self.backup_gcp_sa_secret()
            response: subprocess.CompletedProcess = run_cmd(
                "kubectl create secret generic dac-gcp-sa --save-config --dry-run=client --from-file=dac-gcp-sa=%s -n %s -o yaml"
                % (src_filename, self.namespace),
                failure_cb=SatoriDeployer.on_update_secret_failure,
                failure_cb_arg="dac-gcp-sa",
            )
            if response.returncode == 0:
                run_cmd(
                    "kubectl apply -f -",
                    input=response.stdout,
                    failure_cb=SatoriDeployer.on_update_secret_failure,
                    failure_cb_arg="dac-gcp-sa",
                )
                self.annotate_secret("dac-gcp-sa", "version", latest_version)
        os.remove(src_filename)
        self.update_secret_metrics("dac-gcp-sa", latest_version)

    def populate_service_account_secret(self, secret_id):
        self.populate_secret_file(secret_id, "service_account.json")

    def populate_service_accounts(self, secret_ids):
        for secret_id in secret_ids:
            logger.info("Populating service account secret %s", secret_id)
            self.populate_service_account_secret(secret_id)

    def populate_docker_registry_secret(self):
        secret_id = "pull-gcr-sa"
        latest_version, secret = self.gcp_access.download_secret(secret_id)
        if self.should_update_secret(secret_id, latest_version):
            secret_json = json.loads(secret)
            response: subprocess.CompletedProcess = run_cmd(
                [
                    "kubectl",
                    "-n",
                    self.namespace,
                    "create",
                    "secret",
                    "docker-registry",
                    secret_id,
                    "--docker-server=https://us-docker.pkg.dev",
                    "--docker-username=_json_key",
                    "--docker-password=%s" % json.dumps(secret_json),
                    "--docker-email=ops@satoricyber.com",
                    "--save-config",
                    "--dry-run=client",
                    "-o",
                    "yaml",
                ],
                failure_cb=SatoriDeployer.on_update_secret_failure,
                failure_cb_arg=secret_id,
            )
            if response.returncode == 0:
                run_cmd(
                    "kubectl apply -f -",
                    input=response.stdout,
                    failure_cb=SatoriDeployer.on_update_secret_failure,
                    failure_cb_arg=secret_id,
                )
                self.annotate_secret(secret_id, "version", latest_version)
            json_str = json.dumps({"imagePullSecrets": [{"name": "pull-gcr-sa"}]})
            run_cmd(
                [
                    "kubectl",
                    "-n",
                    self.namespace,
                    "patch",
                    "serviceaccount",
                    "default",
                    "-p",
                    json_str,
                ],
                failure_cb=SatoriDeployer.on_update_secret_failure,
                failure_cb_arg=secret_id,
            )
            logger.info(
                "Credentials to pull images from satori container registry updated"
            )
        self.update_secret_metrics(secret_id, latest_version)

    def download_certificate(self, secret_id):
        if self.dac_installer:
            temp_dir = DAC_INSTALLER_SECRET_PATH
        else:
            temp_dir = tempfile.mkdtemp()
        filename_tar_b64 = os.path.join(temp_dir, "%s.tgz.b64" % secret_id)
        self.download_secret_to_file(secret_id, filename_tar_b64)
        filename_tar = os.path.join(temp_dir, "%s.tgz" % secret_id)
        with open(filename_tar_b64, "r") as fb64:
            decoded = base64.b64decode(fb64.read())
            with open(filename_tar, "wb") as f:
                f.write(decoded)

        tf = tarfile.open(filename_tar)
        tf.extractall(temp_dir)
        return temp_dir

    def download_certificate_from_json(self, secret_id):
        if self.dac_installer:
            temp_dir = DAC_INSTALLER_SECRET_PATH
        else:
            temp_dir = tempfile.mkdtemp()
        logger.info("Download secret %s", secret_id)
        version, secret_data = self.gcp_access.download_secret(secret_id)

        logger.info("Store json secret %s in files", secret_id)
        secret_data_json = json.loads(secret_data)

        for key, value in secret_data_json.items():
            logger.info("Store secret %s in file", key)
            filename = os.path.join(temp_dir, key)
            f = open(filename, "w")
            f.write(value)
            f.close()

        return temp_dir, version

    def populate_certificates(self):
        if self.no_client_tls is False:
            temp_dir, latest_version = self.download_certificate_from_json("cert-tls")
            try:
                if self.should_update_secret("cert-tls", latest_version):
                    response: subprocess.CompletedProcess = run_cmd(
                        [
                            "kubectl",
                            "create",
                            "secret",
                            "generic",
                            "cert-tls",
                            "--from-file=%s" % os.path.join(temp_dir, "privkey.pem"),
                            "--from-file=%s" % os.path.join(temp_dir, "fullchain.pem"),
                            "-n",
                            self.namespace,
                            "--save-config",
                            "--dry-run=client",
                            "-o",
                            "yaml",
                        ],
                        failure_cb=SatoriDeployer.on_update_secret_failure,
                        failure_cb_arg="cert-tls",
                    )
                    if response.returncode == 0:
                        run_cmd(
                            "kubectl apply -f -",
                            input=response.stdout,
                            failure_cb=SatoriDeployer.on_update_secret_failure,
                            failure_cb_arg="cert-tls",
                        )
                    self.annotate_secret("cert-tls", "version", latest_version)
                    logger.info("The secret %s updated successfully", "cert-tls")
            finally:
                shutil.rmtree(temp_dir, ignore_errors=True)
                self.update_secret_metrics("cert-tls", latest_version)

        try:
            temp_dir, latest_version = self.download_certificate_from_json(
                "cert-tls-local"
            )
            if self.should_update_secret("cert-tls-local", latest_version):
                response: subprocess.CompletedProcess = run_cmd(
                    [
                        "kubectl",
                        "create",
                        "secret",
                        "generic",
                        "cert-tls-local",
                        "--from-file=%s" % os.path.join(temp_dir, "cert.pem"),
                        "--from-file=%s" % os.path.join(temp_dir, "privkey.pem"),
                        "--from-file=%s" % os.path.join(temp_dir, "chain.pem"),
                        "--from-file=%s" % os.path.join(temp_dir, "fullchain.pem"),
                        "--from-file=%s" % os.path.join(temp_dir, "identity.pfx"),
                        "-n",
                        self.namespace,
                        "--save-config",
                        "--dry-run=client",
                        "-o",
                        "yaml",
                    ],
                    failure_cb=SatoriDeployer.on_update_secret_failure,
                    failure_cb_arg="cert-tls-local",
                )
                if response.returncode == 0:
                    run_cmd(
                        "kubectl apply -f -",
                        input=response.stdout,
                        failure_cb=SatoriDeployer.on_update_secret_failure,
                        failure_cb_arg="cert-tls-local",
                    )
                    self.annotate_secret("cert-tls-local", "version", latest_version)
                logger.info("The secret cert-tls-local updated successfully")
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)
            self.update_secret_metrics("cert-tls-local", latest_version)

    def set_nlb_readiness_gate(self):
        run_cmd(
            "kubectl label namespace %s elbv2.k8s.aws/pod-readiness-gate-inject=enabled --overwrite"
            % (K8S_NAMESPACE)
        )
        logger.info("NLB controller readiness label is created")

    def populate_literal_secret(self, secret_id):
        latest_version, payload = self.gcp_access.download_secret(secret_id)
        if self.should_update_secret(secret_id, latest_version):
            response: subprocess.CompletedProcess = run_cmd(
                "kubectl create secret generic %s --save-config --dry-run=client --from-literal=%s -n %s -o yaml"
                % (secret_id, payload, self.namespace),
                failure_cb=SatoriDeployer.on_update_secret_failure,
                failure_cb_arg=secret_id,
            )
            if response.returncode == 0:
                run_cmd(
                    "kubectl apply -f -",
                    input=response.stdout,
                    failure_cb=SatoriDeployer.on_update_secret_failure,
                    failure_cb_arg=secret_id,
                )
                self.annotate_secret(secret_id, "version", latest_version)
            logger.info("Created literal secret %s", secret_id)
        self.update_secret_metrics(secret_id, latest_version)

    def populate_empty_secret(self, secret_id):
        run_cmd(
            "kubectl create secret generic %s -n %s" % (secret_id, self.namespace),
            can_fail=True,
        )
        logger.info("Created literal secret %s", secret_id)

    def populate_literal_secrets(self, secret_ids):
        for secret_id in secret_ids:
            logger.info("Populating secret %s", secret_id)
            self.populate_literal_secret(secret_id)

    def populate_empty_secrets(self, secret_ids):
        for secret_id in secret_ids:
            logger.info("Populating empty secret: %s", secret_id)
            self.populate_empty_secret(secret_id)

    def restart_pods(self):
        resources = ["statefulset", "deployment", "daemonset"]

        for resource in resources:
            res: subprocess.CompletedProcess = run_cmd(
                "kubectl get %s -n %s -o custom-columns=:metadata.name --no-headers"
                % (resource, self.namespace)
            )
            if res.returncode == 0:
                names = res.stdout.decode("utf-8").splitlines()
                for name in names:
                    if self.secret_used_by_resource(resource, name):
                        logger.info(f"Restarting %s: %s" % (resource, name))
                        run_cmd(
                            "kubectl rollout restart %s %s -n %s"
                            % (resource, name, self.namespace)
                        )
                        self.metrics.num_restarts.labels(name).inc()


    def download_secrets(self):
        self.populate_gcp_sa_secret()
        self.populate_service_accounts(
            ["pub-sub-sa", "config-client-sa", "mixer-keys", "dns-updater-sa", "monitoring-access-sa","mgmt-api-sa"]
        )
        self.populate_secret_file("idp-token-access-sa", "idp-token-access.json")
        self.populate_literal_secrets(["snowflake-digest-key"])
        self.populate_docker_registry_secret()
        self.populate_certificates()
        if not self.secret_rotation:
            self.populate_empty_secrets(["datastore-custom-certificate"])


def deploy_handler(args, deployer: SatoriDeployer):
    deployer.download_secrets()
    deployer.set_nlb_readiness_gate()


def secret_rotation_handler(args, deployer: SatoriDeployer):
    global status_code
    try:
        deployer.download_secrets()

        # restart pods if any secret was updated
        if deployer.updated_secrets:
            deployer.restart_pods()
    except Exception as e:
        logger.info(f"secret rotation failed with error {e}")
        status_code = 1
    else:
        deployer.metrics.last_run.labels(status=0).set(int(time.time()))
        logger.info("finish successfully")


@atexit.register
def on_exit():
    global satori_deployer, status_code
    satori_deployer.metrics.last_run.labels(status=status_code).set(int(time.time()))
    satori_deployer.metrics.write_metrics_to_redis()


if __name__ == "__main__":
    satori_parser = argparse.ArgumentParser(prog="python3 satori.py")
    deploy_sub_parser = satori_parser.add_subparsers()

    # deployment
    deploy_parser = deploy_sub_parser.add_parser(
        "deploy", description="Deploy management"
    )
    deploy_parser.set_defaults(func=deploy_handler)
    deploy_parser.add_argument(
        "--dac_installer",
        nargs="?",
        help="Internal use by dac-installer",
        const=True,
        required=False,
    )
    deploy_parser.add_argument(
        "--bootstrap_otp",
        type=str,
        help="One time URL to retrieve GCP service account",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--sa_id",
        type=str,
        help="service account ID to retrieve GCP service account",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--sa_key",
        type=str,
        help="service account key to retrieve GCP service account",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--sa_secret",
        type=str,
        help="service account secret name to retrieve GCP service account",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--dac_id",
        type=str,
        help="DAC ID",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--mgmtApiHost",
        type=str,
        help="management API hostname",
        required=False,
        default="app.satoricyber.com",
    )

    secret_rotation_parser = deploy_sub_parser.add_parser(
        "rotate", description="Rotate secrets"
    )
    secret_rotation_parser.set_defaults(func=secret_rotation_handler)

    # parse and handle
    args = satori_parser.parse_args()

    # installation or secret rotation job
    secret_rotation = args.func == secret_rotation_handler

    satori_deployer = SatoriDeployer(args, secret_rotation)
    args.func(args, satori_deployer)
