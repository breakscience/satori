from typing import Optional
import redis
from redis.sentinel import Sentinel
from os import environ
import logging

# Note: when we will deprecate ha proxy this should be updated
DEFAULT_REDIS_HOST = "runtime-redis-ha-haproxy"
SENTINEL_DEFAULT_PORT = "26379"
# Default Redis Sentinel service name used in our redis-ha deployment
SENTINEL_DEFAULT_GROUP = "mymaster"


def get_redis_endpoints_from_env() -> list[str]:
    """
    Get Redis endpoints from environment variable.

    Expects a comma-separated list of hostnames from REDIS_ENDPOINT environment variable.
    If not set, defaults to DEFAULT_REDIS_HOST. Single hostname is used for direct
    Redis connection, multiple hostnames are used for Redis Sentinel.

    Returns:
        list[str]: List of Redis endpoint hostnames
    """
    return [
        endpoint.strip()
        for endpoint in environ.get(
            "REDIS_ENDPOINT", environ.get("REDIS_HOSTNAME", DEFAULT_REDIS_HOST)
        ).split(",")
    ]


def get_redis_sentinel_port() -> str:
    """
    Get Redis Sentinel port from environment variable.

    Returns:
        str: Redis Sentinel port number (default: "26379")
    """
    return environ.get("REDIS_SENTINEL_PORT", SENTINEL_DEFAULT_PORT)


def get_redis_sentinel_svc_name() -> str:
    """
    Get Redis Sentinel service name from environment variable.

    Returns:
        str: Redis Sentinel service name (default: "mymaster")
    """
    return environ.get("REDIS_SENTINEL_SERVICE_NAME", SENTINEL_DEFAULT_GROUP)


def get_redis_ha(
    logger: logging.Logger, endpoints: Optional[list[str]] = None
) -> redis.Redis:
    """
    Get Redis High Availability connection using Sentinel or direct connection.

    If multiple Redis endpoints are provided, uses Redis Sentinel for HA.
    If only one endpoint is provided, creates a direct Redis connection.

    Args:
        logger (logging): Logger instance for debugging output

    Returns:
        redis.Redis: Redis connection instance
    """
    redis_hostnames = (
        endpoints if endpoints is not None else get_redis_endpoints_from_env()
    )
    if len(redis_hostnames) > 1:
        logger.info("Redis Sentinels: %s", redis_hostnames)
        redis_hostnames = [
            (endpoint, get_redis_sentinel_port()) for endpoint in redis_hostnames
        ]
        logger.info("Using Sentinel endpoints %s", redis_hostnames)
        sentinel = Sentinel(
            redis_hostnames,
            socket_timeout=0.1,
        )
        return sentinel.master_for(
            service_name=get_redis_sentinel_svc_name(),
        )
    else:
        hostname = redis_hostnames[0] if redis_hostnames else DEFAULT_REDIS_HOST
        logger.info("Using direct redis connection %s", hostname)
        return redis.Redis(
            host=hostname,
        )
