import json
from google.cloud import secretmanager
import base64
import requests
import subprocess
from enum import Enum
from utils.utils import get_logger, run_cmd
from prometheus_metrics.prometheus_metrics import Metrics


logger = get_logger()


class GCPErrors(Enum):
    SECRET = 1  # failed to use GCP SA from secret dac-gcp-sa


class GoogleAccess:
    def __init__(self, args, namespace: str, metrics: Metrics):
        self.gcp_sa_info = {}
        self.secret_manager = self.get_gcp_service_account(args, namespace, metrics)
        self.project_id = self.gcp_sa_info["project_id"]
        return

    def handle_gcp_response(self, response: str) -> bool:
        if response.status_code == 200:
            self.gcp_sa_info = json.loads(response.json()["gsa"])
            return True
        logger.error(
            f"Failed to get GCP service account, status code: {response.status_code}, response: {response.content}"
        )
        return False

    def get_secret_manager(self):
        secret_manager = (
            secretmanager.SecretManagerServiceClient.from_service_account_info(
                self.gcp_sa_info
            )
        )
        return secret_manager

    def generate_token(
        self, service_Account_id: str, service_account_key: str, mgmtApiHost: str
    ) -> str:
        url = f"https://{mgmtApiHost}/api/authentication/token"
        body = {
            "serviceAccountId": service_Account_id,
            "serviceAccountKey": service_account_key,
        }
        logger.info(f"getting token from URL: {url}")
        results = requests.post(url=url, json=body)
        try:
            return results.json()["token"]
        except Exception as e:
            logger.error(
                f"Fail to get access token, error {e}, status code: {results.status_code}"
            )

    def get_gcp_service_account(self, args, namespace, metrics: Metrics):
        """
        get google service account which is used to download all secrets
        we try to read the sa and connect to gcp in the following order:
        1. bootstrap OTP (1 time URL)
        2. management service account
        3. dac-gcp-sa Kubernetes secret
        4. dac-gcp-sa-previous Kubernetes secret (previous version of dac-gcp-sa)
        """
        # retrieve GCP with one time token
        try:
            bootstrap_otp = getattr(args, "bootstrap_otp", "")
            if bootstrap_otp is not None and len(bootstrap_otp) > 0:
                logger.info("trying to download GCP with one time token...")
                decoded_url = base64.b64decode(args.bootstrap_otp)
                response = requests.get(decoded_url)
                if self.handle_gcp_response(
                    response,
                ):
                    return self.get_secret_manager()
        except Exception as e:
            logger.error(f"Failed to get GCP service account with error: {e}")
            self.gcp_sa_info = {}

        # retrieve GCP with service account
        try:
            sa_id = getattr(args, "sa_id", "")
            sa_key = getattr(args, "sa_key", "")
            sa_secret = getattr(args, "sa_secret", "")
            dac_id = getattr(args, "dac_id", "")
            mgmtApiHost = getattr(args, "mgmtApiHost", "app.satoricyber.com")

            if len(sa_secret) > 0 and (len(sa_id) == 0 or len(sa_key) == 0):
                logger.info(f"trying to read service account from secret {sa_secret}")
                response: subprocess.CompletedProcess = run_cmd("kubectl get secret %s -n %s -o=jsonpath='{.data.service_account\.json}'" %
                                                                (sa_secret, namespace), can_fail=True)
                if response.returncode == 0:
                    serive_account = json.loads(base64.b64decode(response.stdout).decode('utf-8'))
                    sa_key = serive_account["key"]
                    sa_id = serive_account["id"]
                    logger.info(f"service account was extracted from secret {sa_secret}")

            if (
                sa_id is not None
                and len(sa_id) > 0
                and sa_key is not None
                and len(sa_key) > 0
            ):
                logger.info("trying to download GCP with service account")
                token = self.generate_token(sa_id, sa_key, mgmtApiHost)
                url = f"https://{mgmtApiHost}/api/data-access-controllers/google-sa?id={dac_id}"
                headers = {
                    "Authorization": f"Bearer {token}",
                }
                logger.info(f"getting GCP from URL: {url}")
                response = requests.get(url, headers=headers)
                if self.handle_gcp_response(response):
                    return self.get_secret_manager()
        except Exception as e:
            logger.error(f"Failed to get GCP service account with error: {e}")
            self.gcp_sa_info = {}

        # read GCP from secret
        try:
            logger.info("trying to read GCP from secret")
            response: subprocess.CompletedProcess = run_cmd(
                "kubectl get secret dac-gcp-sa -n %s -o=jsonpath='{.data.dac-gcp-sa}'"
                % (namespace),
                can_fail=True,
            )
            if response.returncode == 0:
                self.gcp_sa_info = json.loads(
                    base64.b64decode(response.stdout).decode("utf-8")
                )
                return self.get_secret_manager()
        except Exception as e:
            logger.error(f"Failed to get GCP service account with error: {e}")
            self.gcp_sa_info = {}

        metrics.gcp_errors.labels(GCPErrors.SECRET.name).inc()

        # read GCP from backup secret
        try:
            logger.info("trying to read GCP from backup secret")
            response: subprocess.CompletedProcess = run_cmd(
                "kubectl get secret dac-gcp-sa-previous -n %s -o=jsonpath='{.data.dac-gcp-sa}'"
                % (namespace),
                can_fail=True,
            )
            if response.returncode == 0:
                self.gcp_sa_info = json.loads(
                    base64.b64decode(response.stdout).decode("utf-8")
                )
                return self.get_secret_manager()
        except Exception as e:
            logger.error(f"Failed to get GCP service account with error: {e}")
            self.gcp_sa_info = {}

    def download_secret(self, secret_id):
        path = self.secret_manager.secret_version_path(
            self.project_id, secret_id, "latest"
        )
        request = {"name": path}
        response = self.secret_manager.access_secret_version(request)
        version = response.name.split("/")[-1]
        payload = response.payload.data.decode("UTF-8")
        logger.info("Download version %s for %s" % (version, secret_id))
        return version, payload
