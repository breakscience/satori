from __future__ import annotations
import argparse
import base64
from distutils.util import strtobool
from typing import Any, Callable, List, Optional, Union
import click
import csv
try:
    from google.cloud import secretmanager
    from google.cloud.secretmanager import Replication, Secret, SecretPayload
    updated_secret_manager = True
except ImportError:
    updated_secret_manager = False
    from google.cloud import secretmanager_v1beta1 as secretmanager
    from google.cloud.secretmanager_v1beta1.proto import resources_pb2
from google.cloud import storage
from google.api_core.exceptions import AlreadyExists
import json
import os
import logging
import shutil
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime
import glob
import requests


# Important: this script should be able to run in multiple environments, linux distros and OSs (even windows).
# Take extra care not to introduce anything that is platform-specific:
# - Prefer python native solutions over launching commands in a shell
# - When working with files, make sure to use os.path.join instead of concatenating / (windows...)
#
# Test your work on the following supportability matrix:
# - Python versions: 3.6, 3.7, 3.8
# - Operating systems: OSX, Centos, Ubuntu, Windows


DAC_INSTALLER_SECRET_PATH = "/satori_tmp/"
K8S_NAMESPACE = os.environ.get("POD_NAMESPACE", "satori-runtime")


SecretId = str
SecretPath = str


def _connect_gcp_secret_manager(logger: logging.Logger, env: Env, args):
    secret_manager = get_gcp_service_account(args, env)
    env.project_id = env.gcp_sa_info["project_id"]

    logger.info(
        "Successfully connected to Google secrect manager, project-id: %s", env.project_id
    )
    return secret_manager


class LogCollector:
    def __init__(self, env: Env, upload):
        self.env: Env = env
        self.logger: logging.Logger = env.logger
        self.project_id = env.project_id
        self.should_upload = upload

    def collect(self):
        self.env.confirm_k8()
        temp_dir = tempfile.mkdtemp()
        self.logger.debug("Writing temp files to %s", temp_dir)
        try:
            self._collect_resources(temp_dir)
            self._collect_pod_logs(temp_dir)
            self._collect_nginx_logs(temp_dir)
            archive = self._create_archive(temp_dir)
            if self.should_upload:
                self._upload(self.project_id, archive)
        finally:
            self.logger.debug("cleaning up temp files")
            shutil.rmtree(temp_dir, ignore_errors=True)

    # Dumps all satori resources into a file
    def _collect_resources(self, temp_dir: str):
        with open(os.path.join(temp_dir, "k8.txt"), "w") as f:
            self.env.cmd("kubectl get all --namespace %s" % (K8S_NAMESPACE), stdout=f)

    # Collects all pod logs
    def _collect_pod_logs(self, temp_dir):
        pods = []
        with open(os.path.join(temp_dir, "pods.txt"), "w") as f:
            self.env.cmd("kubectl get pods --namespace %s" % (K8S_NAMESPACE), stdout=f)
        with open(os.path.join(temp_dir, "pods.txt"), "r") as f:
            csv_reader = csv.reader(f, delimiter=" ", skipinitialspace=True)
            line_count = 0
            for row in csv_reader:
                if line_count > 0:
                    pods.append(row[0].strip())
                line_count += 1
            self.logger.debug("Found %d pods: %s", len(pods), pods)
            for pod in pods:
                with open("%s.log" % os.path.join(temp_dir, pod), "w") as f:
                    self.env.cmd(
                        [
                            "kubectl",
                            "logs",
                            pod,
                            "--all-containers=true",
                            "--namespace",
                            K8S_NAMESPACE,
                        ],
                        stdout=f,
                        can_fail=True,
                    )
                    print(".", end="", flush=True)
            print(".")

    # Dumps the nginx configuration to help with debugging
    def _collect_nginx_logs(self, temp_dir):
        with open(os.path.join(temp_dir, "proxy.conf"), "w") as f:
            self.env.cmd(
                [
                    "kubectl",
                    "exec",
                    "-n",
                    K8S_NAMESPACE,
                    "satori-runtime-proxy-0",
                    "-c",
                    "proxy",
                    "--",
                    "bash",
                    "-c",
                    "/etc/nginx/nginx -T",
                ],
                stdout=f,
                can_fail=True,
            )
        with open(os.path.join(temp_dir, "http-proxy.conf"), "w") as f:
            self.env.cmd(
                [
                    "kubectl",
                    "exec",
                    "-n",
                    K8S_NAMESPACE,
                    "satori-runtime-http-proxy-0",
                    "-c",
                    "http-proxy",
                    "--",
                    "bash",
                    "-c",
                    "/usr/local/openresty/nginx/sbin/nginx -T",
                ],
                stdout=f,
                can_fail=True,
            )

    def _create_archive(self, temp_dir):
        dir = "satori-logs-%s" % datetime.now().strftime("%Y%m%d_%H%M")
        archive = "%s.tar.gz" % dir
        with tarfile.open(archive, "w:gz") as tar:
            tar.add(temp_dir, arcname=dir)
        print("Archive %s created" % archive)
        return archive

    def _upload(self, project_id, source_file):
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "./dac-secrets-sa.json"
        storage_client = storage.Client()
        bucket = storage_client.bucket(project_id)
        blob = bucket.blob(source_file)
        blob.upload_from_filename(source_file)
        print("File {} uploaded ".format(source_file))


class SatoriDeployer:
    def __init__(self, env):
        self.env: Env = env
        self.namespace = K8S_NAMESPACE
        self.updated_secrets = set()
        self.logger: logging.Logger = env.logger
        # self.logger.info("Starting deployer to data access controller %s", self.env.project_id)

        self.secret_manager = get_gcp_service_account(args, env)

        self.env.project_id = self.env.gcp_sa_info["project_id"]
        self.logger.debug("Secret manager client created successfully")

    def secret_used_by_resource(self, resource_type, resource_name):
        secret_names = []
        self.logger.info("checking if %s %s should be restarted " % (resource_type, resource_name))

        # list all secrets that are used by this resource as volumes
        secret_volumes: subprocess.CompletedProcess = self.env.cmd(
            "kubectl get %s %s -n %s -o jsonpath=\'{.spec.template.spec.volumes[*].secret.secretName}\'" % (resource_type, resource_name, self.namespace),
            can_fail = True
        )
        if secret_volumes.returncode == 0:
            secret_names = secret_volumes.stdout.decode('UTF-8').strip(' "\'\t\r\n').split()

        # list all secrets that are used by this resource as ENV variable
        secret_env: subprocess.CompletedProcess = self.env.cmd(
            "kubectl get %s %s -n %s -o jsonpath=\'{.spec.template.spec.containers[0].env[?(@.valueFrom.secretKeyRef.name)].valueFrom.secretKeyRef.name}\'" % (resource_type, resource_name, self.namespace),
            can_fail = True
        )
        if secret_env.returncode == 0:
            secret_names.extend(secret_env.stdout.decode('UTF-8').strip(' "\'\t\r\n').split())

        # check id one of the secrets that are used by this resource was updated
        for secret_name in secret_names:
            if secret_name in self.updated_secrets:
                self.logger.info("new version of secret %s was found" % secret_name)
                return True
            else:
                self.logger.info("secret %s wasn't updated" % secret_name)

        self.logger.info("No need to restart %s %s" % (resource_type, resource_name))

    def download_secret(self, secret_id):
        path = self.secret_manager.secret_version_path(
            self.env.project_id, secret_id, "latest"
        )
        request = {"name": path}
        if updated_secret_manager is True:
            response = self.secret_manager.access_secret_version(request)
        else:
            response = self.secret_manager.access_secret_version(path)
        version = response.name.split('/')[-1]
        payload = response.payload.data.decode("UTF-8")

        self.logger.info("Download version %s for %s" % (version, secret_id))
        return version, payload

    def download_secret_to_file(self, secret_id, filename):
        version, payload = self.download_secret(secret_id)
        with open(filename, "w") as secret_file:
            secret_file.write(payload)
        return version

    def delete_secret(self, secret_id):
        self.env.cmd(
            "kubectl delete secret %s -n %s" % (secret_id, self.namespace), True
        )


    def create_namespace(self):
        self.env.cmd("kubectl create namespace %s" % (K8S_NAMESPACE), True)
        self.logger.info("Namespace %s created",K8S_NAMESPACE)


    def should_update_secret(self, secret_id, latest_version):
        if self.env.secret_rotation:
            try:
                response: subprocess.CompletedProcess = self.env.cmd(
                    "kubectl get secret %s -n %s -o json"
                    % (secret_id, self.namespace),
                    can_fail=True
                )
                if response.returncode == 0:
                    secret_info = json.loads(response.stdout)
                    curr_version = secret_info.get("metadata", {}).get("annotations", {}).get("version", None)
                    update_secret = curr_version is None or curr_version != latest_version
                    self.logger.info(
                        "{} to update secret {}: {} -> {}".format("Going to" if update_secret else "No need", secret_id, curr_version, latest_version))
                    if update_secret:
                        self.updated_secrets.add(secret_id)
                    return update_secret
            except Exception as e:
                self.logger.error(
                    f"Fail to read secret {secret_id} version, error {e}")
        self.updated_secrets.add(secret_id)
        return True

    def annotate_secret(self, secret_id: str, annotation_name: str, annotation_value: str):
        try:
            self.env.cmd(
                "kubectl annotate secret %s --overwrite %s=%s -n %s"
                % (secret_id, annotation_name, annotation_value, self.namespace)
            )
        except Exception as e:
                self.logger.error(
                    f"Fail to annotate secret {secret_id}, error {e}")

    def populate_secret_file(self, secret_id, dst_filename):
        src_filename = ""
        # always update during installation
        if self.env.dac_installer is True:
            src_filename = DAC_INSTALLER_SECRET_PATH
        src_filename += "%s.secret" % secret_id
        latest_version = self.download_secret_to_file(secret_id, src_filename)
        if self.should_update_secret(secret_id, latest_version):
            response: subprocess.CompletedProcess = self.env.cmd(
                "kubectl create secret generic %s --save-config --dry-run=client --from-file=%s=%s -n %s -o yaml"
                % (secret_id, dst_filename, src_filename, self.namespace)
            )
            if response.returncode == 0:
                self.env.cmd(
                    "kubectl apply -f -",
                    input=response.stdout,
                    can_fail=True
                )
                self.annotate_secret(secret_id, "version", latest_version)
        os.remove(src_filename)

    def backup_gcp_sa_secret(self, force=True):
        '''
            create a backup secert for dac-gcp-sa before rotation
            from self.env.gcp_sa_info which is the latest working service account
        '''
        try:
            if force:
                self.logger.info("backup dac-gcp-sa")
                response: subprocess.CompletedProcess = self.env.cmd([
                    "kubectl",
                    "create",
                    "secret",
                    "generic",
                    "dac-gcp-sa-previous",
                    f"--from-literal=dac-gcp-sa={json.dumps(self.env.gcp_sa_info)}",
                    "-n",
                    self.namespace,
                    "--save-config",
                    "--dry-run=client",
                    "-o",
                    "yaml"]
                )
                if response.returncode == 0:
                    env.cmd("kubectl apply -f -", input=response.stdout, can_fail=True)
                    self.logger.error("dac-gcp-sa-previous was created successfully")
            else:
                # don't overwrite if exists
                response: subprocess.CompletedProcess = self.env.cmd([
                    "kubectl",
                    "create",
                    "secret",
                    "generic",
                    "dac-gcp-sa-previous",
                    f"--from-literal=dac-gcp-sa={json.dumps(self.env.gcp_sa_info)}",
                    "-n",
                    self.namespace],
                    can_fail=True
                )

        except Exception as e:
            self.logger.error(
                f"Fail to backup gcp service account secret, error {e}")

    def populate_gcp_sa_secret(self):
        try:
            src_filename = ""
            if self.env.dac_installer is True:
                src_filename = DAC_INSTALLER_SECRET_PATH
            src_filename += "dac-gcp-sa.secret"
            latest_version = self.download_secret_to_file("dac-secrets-sa", src_filename)
            if self.should_update_secret("dac-gcp-sa", latest_version):
                # save backup before rotating the secret
                self.backup_gcp_sa_secret()
                response: subprocess.CompletedProcess = self.env.cmd(
                    "kubectl create secret generic dac-gcp-sa --save-config --dry-run=client --from-file=dac-gcp-sa=%s -n %s -o yaml"
                    % (src_filename, self.namespace)
                )
                if response.returncode == 0:
                    self.env.cmd(
                    "kubectl apply -f -",
                    input=response.stdout,
                    can_fail=True
                    )
                    self.annotate_secret("dac-gcp-sa", "version", latest_version)
            os.remove(src_filename)
        except Exception as e:
            if not self.env.secret_rotation:
                # backup gcp sa if we are in a middle of deployment
                self.backup_gcp_sa_secret(force=False)
            self.logger.error(
                f"Fail to populate gcp service account secret, error {e}")

    def populate_service_account_secret(self, secret_id):
        self.populate_secret_file(secret_id, "service_account.json")

    def populate_service_accounts(self, secret_ids):
        for secret_id in secret_ids:
            self.logger.info("Populating service account secret %s", secret_id)
            self.populate_service_account_secret(secret_id)

    def populate_docker_registry_secret(self):
        secret_id = "pull-gcr-sa"
        latest_version, secret = self.download_secret(secret_id)
        if self.should_update_secret(secret_id, latest_version):
            secret_json = json.loads(secret)
            response: subprocess.CompletedProcess = self.env.cmd(
                [
                    "kubectl",
                    "-n",
                    self.namespace,
                    "create",
                    "secret",
                    "docker-registry",
                    secret_id,
                    "--docker-server=https://us-docker.pkg.dev",
                    "--docker-username=_json_key",
                    "--docker-password=%s" % json.dumps(secret_json),
                    "--docker-email=ops@satoricyber.com",
                    "--save-config",
                    "--dry-run=client",
                    "-o",
                    "yaml"
                ]
            )
            if response.returncode == 0:
                self.env.cmd(
                    "kubectl apply -f -",
                    input=response.stdout,
                    can_fail=True
                )
                self.annotate_secret(secret_id, "version", latest_version)
            json_str = json.dumps({"imagePullSecrets": [{"name": "pull-gcr-sa"}]})
            self.env.cmd(
                [
                    "kubectl",
                    "-n",
                    self.namespace,
                    "patch",
                    "serviceaccount",
                    "default",
                    "-p",
                    json_str,
                ]
            )
            self.logger.info("Credentials to pull images from satori container registry updated")

    def download_certificate(self, secret_id):
        if self.env.dac_installer is True:
            temp_dir = DAC_INSTALLER_SECRET_PATH
        else:
            temp_dir = tempfile.mkdtemp()
        filename_tar_b64 = os.path.join(temp_dir, "%s.tgz.b64" % secret_id)
        self.download_secret_to_file(secret_id, filename_tar_b64)
        filename_tar = os.path.join(temp_dir, "%s.tgz" % secret_id)
        with open(filename_tar_b64, "r") as fb64:
            decoded = base64.b64decode(fb64.read())
            with open(filename_tar, "wb") as f:
                f.write(decoded)

        tf = tarfile.open(filename_tar)
        tf.extractall(temp_dir)
        return temp_dir
    
    def download_certificate_from_json(self, secret_id):
        if self.env.dac_installer is True:
            temp_dir = DAC_INSTALLER_SECRET_PATH
        else:
            temp_dir = tempfile.mkdtemp()
        self.logger.info("Download secret %s", secret_id)
        version, secret_data = self.download_secret(secret_id)
       
        self.logger.info("Store json secret %s in files", secret_id)
        secret_data_json = json.loads(secret_data)
              
        for key, value in secret_data_json.items():
          self.logger.info("Store secret %s in file", key)
          filename = os.path.join(temp_dir, key)
          f = open(filename, "w")
          f.write(value)
          f.close()

        return temp_dir, version

    def populate_certificates(self):
        if self.env.no_client_tls is False:
            temp_dir, latest_version = self.download_certificate_from_json("cert-tls")
            try:
                if self.should_update_secret("cert-tls", latest_version):
                    response: subprocess.CompletedProcess = self.env.cmd(
                        [
                            "kubectl",
                            "create",
                            "secret",
                            "generic",
                            "cert-tls",
                            "--from-file=%s" % os.path.join(temp_dir, "privkey.pem"),
                            "--from-file=%s" % os.path.join(temp_dir, "fullchain.pem"),
                            "-n",
                            self.namespace,
                            "--save-config",
                            "--dry-run=client",
                            "-o",
                            "yaml"
                        ]
                    )
                    if response.returncode == 0:
                        self.env.cmd(
                            "kubectl apply -f -",
                            input=response.stdout,
                            can_fail=True
                        )
                    self.annotate_secret("cert-tls", "version", latest_version)
                    self.logger.info("The secret %s updated successfully", "cert-tls")
            finally:
                shutil.rmtree(temp_dir, ignore_errors=True)

        try:
            temp_dir, latest_version = self.download_certificate_from_json("cert-tls-local")
            if self.should_update_secret("cert-tls-local", latest_version):
                response: subprocess.CompletedProcess = self.env.cmd(
                    [
                        "kubectl",
                        "create",
                        "secret",
                        "generic",
                        "cert-tls-local",
                        "--from-file=%s" % os.path.join(temp_dir, "cert.pem"),
                        "--from-file=%s" % os.path.join(temp_dir, "privkey.pem"),
                        "--from-file=%s" % os.path.join(temp_dir, "chain.pem"),
                        "--from-file=%s" % os.path.join(temp_dir, "fullchain.pem"),
                        "--from-file=%s" % os.path.join(temp_dir, "identity.pfx"),
                        "-n",
                        self.namespace,
                        "--save-config",
                        "--dry-run=client",
                        "-o",
                        "yaml"
                    ]
                )
                if response.returncode == 0:
                    self.env.cmd(
                        "kubectl apply -f -",
                        input=response.stdout,
                        can_fail=True
                    )
                    self.annotate_secret("cert-tls-local", "version", latest_version)
                self.logger.info("The secret cert-tls-local updated successfully")
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    def populate_prometheus_clusterrole(self):
        if self.env.dac_manager_no_cluster_role is False:
            self.env.cmd("kubectl apply -f runtime-prometheus-server.yaml")
            self.logger.info("Created prometheus clusterrole")
        else:
            self.logger.info("prometheus clusterrole not created")

    def set_nlb_readiness_gate(self):
        self.env.cmd(
            "kubectl label namespace %s elbv2.k8s.aws/pod-readiness-gate-inject=enabled --overwrite" % (K8S_NAMESPACE)
        )
        self.logger.info("NLB controller readiness label is created")

    def populate_literal_secret(self, secret_id):
        latest_version, payload = self.download_secret(secret_id)
        if self.should_update_secret(secret_id, latest_version):
            response: subprocess.CompletedProcess = self.env.cmd(
                "kubectl create secret generic %s --save-config --dry-run=client --from-literal=%s -n %s -o yaml"
                % (secret_id, payload, self.namespace)
            )
            if response.returncode == 0:
                self.env.cmd(
                    "kubectl apply -f -",
                    input=response.stdout,
                    can_fail=True
                )
                self.annotate_secret(secret_id, "version", latest_version)
            self.logger.info("Created literal secret %s", secret_id)

    def populate_empty_secret(self, secret_id):
        self.env.cmd(
            "kubectl create secret generic %s -n %s"
            % (secret_id, self.namespace), can_fail=True
        )
        self.logger.info("Created literal secret %s", secret_id)        

    def populate_literal_secrets(self, secret_ids):
        for secret_id in secret_ids:
            self.logger.info("Populating secret %s", secret_id)
            self.populate_literal_secret(secret_id)
    
    def populate_empty_secrets(self, secret_ids):
        for secret_id in secret_ids:
            self.logger.info("Populating empty secret: %s", secret_id)
            self.populate_empty_secret(secret_id)

    def run_helm(self):
        self.logger.info("Starting helm upgrade")
        helm_cmd = ["helm", "upgrade", "--install", "-n", self.namespace]
        if self.env.helm_wait is True:
            helm_cmd = helm_cmd + ["--wait", "--timeout", self.env.helm_timeout]
        if self.env.helm_atomic is True:
            helm_cmd = helm_cmd + ["--atomic", "--timeout", self.env.helm_timeout]
        if self.env.helm_debug is True:
            helm_cmd.append("--debug")

        if self.env.package_install:
            helm_cmd = helm_cmd + [
                "--values",
                "version-values.yaml",
                "--values",
                "customer-values.yaml",
                "--values",
                "customer-override.yaml",
                "runtime",
                "satori-runtime",
            ]
        else:
            helm_cmd = helm_cmd + [
                "--values",
                "satori-runtime/values.yaml",
                "--values",
                "customer-values.yaml",
                "--values",
                "satori-dac-%s.yaml" % self.env.version,
                "runtime",
                "satori-runtime",
            ]

        self.env.cmd(helm_cmd)
        self.logger.info("Helm upgrade finished successfully")

    def restart_pods(self):

        resources = ["statefulset", "deployment", "daemonset"]

        for resource in resources:
            res: subprocess.CompletedProcess = self.env.cmd(
                "kubectl get %s -n %s -o custom-columns=:metadata.name --no-headers" % (resource, self.namespace)
            )
            if res.returncode == 0:
                names = res.stdout.decode('utf-8').splitlines()
                for name in names:
                    if self.secret_used_by_resource(resource, name):
                        self.logger.info(f"Restarting %s: %s" % (resource, name))
                        self.env.cmd(
                            "kubectl rollout restart %s %s -n %s" % (resource, name, self.namespace)
                        )
    
    def download_secrets(self):
        self.populate_gcp_sa_secret()
        self.populate_service_accounts(["pub-sub-sa", "config-client-sa", "mixer-keys","dns-updater-sa","monitoring-access-sa","mgmt-api-sa"])
        self.populate_secret_file("idp-token-access-sa", "idp-token-access.json")
        self.populate_literal_secrets(["snowflake-digest-key"])
        self.populate_docker_registry_secret()
        self.populate_certificates()
        if not self.env.secret_rotation:
            self.populate_empty_secrets(["datastore-custom-certificate"])

    def deploy(self):
        if self.env.dac_installer is False:
            self.logger.warning("satori.py is deprecated and will be removed at later versions, please use:\n helm upgrade --install --create-namespace -n %s --values version-values.yaml --values customer-values.yaml --values customer-override.yaml runtime satori-runtime",K8S_NAMESPACE)
            self.env.confirm_k8()
            self.verify_correct_cluster()
            self.create_namespace()
        self.download_secrets()
        if self.env.dac_installer is False:
            self.run_helm()
            self.populate_prometheus_clusterrole()
        self.set_nlb_readiness_gate()

    def verify_correct_cluster(self):
        response: subprocess.CompletedProcess = self.env.cmd(
            "helm get values runtime -n %s -o json" % (K8S_NAMESPACE), can_fail=True
        )
        if response.returncode == 1:
            self.logger.debug("Cluster got no DAC installed, continue")
            return
        values = json.loads(response.stdout)
        current_dac = values["configClient"]["repoUrl"].split("/")[4]
        if self.env.project_id != current_dac:
            print(
                f"Another DAC is installed: {current_dac} which doesn't match the new DAC installed {self.env.project_id }"
            )
            print("canceling installation, contact Satori support")
            sys.exit(1)
        else:
            self.logger.debug("Same DAC, continue")


class PrintProxyAddr:
    def __init__(self, env):
        self.env = env
        self.namespace = K8S_NAMESPACE
        self.logger = env.logger
        self.logger.info(
            "getting proxy address from data access controller %s", self.env.project_id
        )

    def get_proxy_addr(self):
        res = self.env.cmd(
            "kubectl get svc satori-runtime-proxy-service -n %s" % (K8S_NAMESPACE)
        )
        if not res:
            self.logger.error("No address yet")
            sys.exit(0)
        return res

    def print(self):
        response = self.get_proxy_addr()
        print(str(response).split()[15])


class UploadSecret:
    def __init__(self, env: Env, args):
        self.env = env
        self.namespace = K8S_NAMESPACE
        self.logger = env.logger
        self.secret_manager = _connect_gcp_secret_manager(self.logger, env, args)

    def create_secret(self, secret_id: SecretId):
        secret_path = "projects/" + self.env.project_id
        if updated_secret_manager is True:
            replication = Replication(
                automatic=Replication.Automatic()
            )
            self._create_secret(self.secret_manager.create_secret, secret_path=secret_path, secret_id=secret_id, secret=Secret(replication=replication))
        else:
            replication = resources_pb2.Replication(
                automatic=resources_pb2.Replication.Automatic()
            )
            self._create_secret(self.secret_manager.create_secret, secret_path=secret_path, secret_id=secret_id, secret=resources_pb2.Secret(replication=replication))
    
    def _create_secret(self, 
                       secret_manager_call: Callable[[SecretPath, #type: ignore
                                                      SecretId,
                                                      Union[Secret,
                                                            resources_pb2.Secret # type: ignore
                                                            ]
                                                        ],
                                                     Any],
                       secret_id: SecretId,
                       secret_path: SecretPath,
                       secret: Union[Secret, #type: ignore
                                     resources_pb2.Secret #type: ignore
                                     ]) -> None:
        try:
            secret_manager_call(secret_path, secret_id, secret)
            self.logger.info(
                "Creates secret-id: %s, project-id: %s",
                    secret_id, self.env.project_id
            )
        except AlreadyExists:
            pass

    def upload_secret(self, secret_id, payload):
        parent = self.secret_manager.secret_path(self.env.project_id, secret_id)
        self.secret_manager.add_secret_version(parent=parent, payload=payload)
        self.logger.info(
            "Added new version for secret-id: {}, project-id: {}".format(
                secret_id, self.env.project_id
            )
        )

    def upload_json_secret_from_files(self, secret_id, *files_tuple):
        secret_dict = {}
        for file_tuple in files_tuple:
            if not os.access(file_tuple[0], os.R_OK):
                self.logger.error(
                    "Unable to read privkey file - {}".format(file_tuple[0])
                )
                sys.exit(0)
            f = open(file_tuple[0], "r")
            file_data = f.read()
            secret_dict[file_tuple[1]] = file_data
        data = json.dumps(secret_dict).encode("UTF-8")
        if updated_secret_manager is True:
           payload = SecretPayload(data=data)
        else:
           payload = resources_pb2.SecretPayload(data=data)
        self.upload_secret(secret_id,payload)
    

class Env:
    def __init__(self, dac_installer: bool):
        self.logger = logging.getLogger("satori")
        self.logger.setLevel(logging.DEBUG)

        if dac_installer is False:
            fh = logging.FileHandler("satori.log")
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(
                logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
            )
            self.logger.addHandler(fh)

        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
        self.logger.addHandler(ch)

        self.assume_yes = False
        self.package_install = False
        self.helm_wait = False
        self.helm_debug = False
        self.helm_atomic = False
        self.helm_timeout = "3h30m"
        self.dac_manager_no_cluster_role = False
        self.dac_installer = False
        self.no_client_tls = False
        self.gcp_sa_info = {}
        self.secret_rotation = False

        if dac_installer is False:
            self.package_install = True
            self.package_name = ""

    def confirm_k8(self):
        if self.assume_yes:
            self.logger.debug("Cluster auto confirmed")
            return
        else:
            res = self.cmd("kubectl config current-context")
            print("Current cluster is: %s" % res.stdout.decode("utf-8"))

        if not click.confirm(
            "Do you want to continue with this cluster?", default=False
        ):
            self.logger.debug("User did not confirm cluster")
            print("Exiting...")
            sys.exit(0)
        self.logger.debug("User confirmed cluster")

    def cmd(
        self,
        command,
        can_fail=False,
        input=None,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ):
        if not isinstance(command, list):
            command = command.split(" ")
        res = subprocess.run(command, stdout=stdout, stderr=stderr, input=input)

        if res.returncode != 0:
            # If the out streams are console, decode them to string for printing to the log
            if stdout == subprocess.PIPE:
                stdout = res.stdout.decode("utf-8")
            if stderr == subprocess.PIPE:
                stderr = res.stderr.decode("utf-8")
            if can_fail:
                self.logger.debug(
                    "Command '%s' returned %d, exiting:\n%s\n%s",
                    " ".join(command),
                    res.returncode,
                    stdout,
                    stderr,
                )
            else:
                self.logger.error(
                    "Command '%s' returned %d, exiting:\n%s\n%s",
                    " ".join(command),
                    res.returncode,
                    stdout,
                    stderr,
                )
                sys.exit(res.returncode)
        else:
            self.logger.debug(
                "Command '%s' finished can_fail=%s rc=%d:",
                " ".join(command),
                can_fail,
                res.returncode,
            )

        return res

class Download:
    def __init__(self, env: Env, args) -> None:
        self.env = env
        self.secret_manager = _connect_gcp_secret_manager(self.env.logger, env, args)
    
    def download_secret(self, secret_id: str):
        self.env.logger.debug("Downloading secret-id %s", secret_id)
        path = self.secret_manager.secret_version_path(
            self.env.project_id, secret_id, "latest"
        )
        request = {
            "name": path,
        }
        res = self.secret_manager.access_secret_version(request)
        self.env.logger.debug("Downloaded secret-id %s", secret_id)
        with open(secret_id, "wb") as f:
            f.write(res.payload.data)

def generate_token(service_Account_id: str, service_account_key: str, mgmtApiHost: str) -> str:
    url = f"https://{mgmtApiHost}/api/authentication/token"
    body = {
        'serviceAccountId': service_Account_id,
        'serviceAccountKey': service_account_key
    }
    logging.info(f"getting token from URL: {url}")
    results = requests.post(url=url, json=body)
    try:
        return results.json()["token"]
    except Exception as e:
        logging.error(
            f"Fail to get access token, error {e}, status code: {results.status_code}")


def handle_gcp_response(response: str, env) -> bool:
    if response.status_code == 200:
        env.gcp_sa_info = json.loads(response.json()["gsa"])
        return True
    logging.error(
        f"Failed to get GCP service account, status code: {response.status_code}, response: {response.content}")
    return False

def get_secret_manager(env):
    secret_manager = (
        secretmanager.SecretManagerServiceClient.from_service_account_info(
            env.gcp_sa_info
        )
    )
    return secret_manager

def get_gcp_service_account(args, env: Env):
    '''
        get google service account which is used to download all secrets
        we try to read the sa and connect to gcp in the following order:
        1. bootstrap OTP (1 time URL)
        2. management service account
        3. dac-gcp-sa Kubernetes secret
        4. dac-gcp-sa-previous Kubernetes secret (previous version of dac-gcp-sa)
    '''
    # retrieve GCP with one time token
    try:
        bootstrap_otp = getattr(args, "bootstrap_otp", "")
        if bootstrap_otp is not None and len(bootstrap_otp) > 0:
            env.logger.info("trying to download GCP with one time token...")
            decoded_url = base64.b64decode(args.bootstrap_otp)
            response = requests.get(decoded_url)
            if handle_gcp_response(response, env):
                return get_secret_manager(env)
    except Exception as e:
        env.logger.error(f"Failed to get GCP service account with error: {e}")
        env.gcp_sa_info = {}

    # retrieve GCP with service account
    try:
        sa_id = getattr(args, "sa_id", "")
        sa_key = getattr(args, "sa_key", "")
        sa_secret = getattr(args, "sa_secret", "")
        dac_id = getattr(args, "dac_id", "")
        mgmtApiHost = getattr(args, "mgmtApiHost", "app.satoricyber.com")

        if len(sa_secret) > 0 and (len(sa_id) == 0 or len(sa_key) == 0):
            env.logger.info(f"trying to read service account from secret {sa_secret}")
            response: subprocess.CompletedProcess = env.cmd("kubectl get secret %s -n %s -o=jsonpath='{.data.service_account\.json}'" %
                                                            (sa_secret, K8S_NAMESPACE), can_fail=True)
            if response.returncode == 0:
                serive_account = json.loads(base64.b64decode(response.stdout).decode('utf-8'))
                sa_key = serive_account["key"]
                sa_id = serive_account["id"]
                env.logger.info(f"service account was extracted from secret {sa_secret}")

        if sa_id is not None and len(sa_id) > 0 and sa_key is not None and len(sa_key) > 0:
            env.logger.info("trying to download GCP with service account")
            token = generate_token(sa_id, sa_key, mgmtApiHost)
            url = f"https://{mgmtApiHost}/api/data-access-controllers/google-sa?id={dac_id}"
            headers = {
                "Authorization": f"Bearer {token}",
            }
            response = requests.get(url, headers=headers)
            if handle_gcp_response(response, env):
                return get_secret_manager(env)
    except Exception as e:
        env.logger.error(f"Failed to get GCP service account with error: {e}")
        env.gcp_sa_info = {}

    # read GCP from secret 
    try:
        env.logger.info("trying to read GCP from secret")
        response: subprocess.CompletedProcess = env.cmd("kubectl get secret dac-gcp-sa -n %s -o=jsonpath='{.data.dac-gcp-sa}'" % (K8S_NAMESPACE), can_fail=True)
        if response.returncode == 0:
            env.gcp_sa_info = json.loads(base64.b64decode(response.stdout).decode('utf-8'))
            return get_secret_manager(env)
    except Exception as e:
        env.logger.error(f"Failed to get GCP service account with error: {e}")
        env.gcp_sa_info = {}

    # read GCP from backup secret
    try:
        env.logger.info("trying to read GCP from backup secret")
        response: subprocess.CompletedProcess = env.cmd("kubectl get secret dac-gcp-sa-previous -n %s -o=jsonpath='{.data.dac-gcp-sa}'" % (K8S_NAMESPACE), can_fail=True)
        if response.returncode == 0:
            env.gcp_sa_info = json.loads(base64.b64decode(response.stdout).decode('utf-8'))
            return get_secret_manager(env)
    except Exception as e:
        env.logger.error(f"Failed to get GCP service account with error: {e}")
        env.gcp_sa_info = {}

def deploy_handler(args, env):
    env.assume_yes = args.yes
    env.helm_wait = args.wait
    env.helm_debug = args.debug
    env.helm_atomic = args.atomic
    env.helm_timeout = args.timeout
    env.dac_manager_no_cluster_role = args.dac_manager_no_cluster_role
    env.dac_installer = args.dac_installer
    env.no_client_tls = args.no_client_tls
    deployer = SatoriDeployer(env)
    deployer.deploy()

def secret_rotation_handler(args, env):
    env.secret_rotation = True
    env.no_client_tls = args.no_client_tls
    env.dac_installer = True
    deployer = SatoriDeployer(env)
    deployer.logger.info("secret_rotation_handler")
    deployer.download_secrets()
    #restart pods if any secret was updated
    if deployer.env.secret_rotation and deployer.updated_secrets:
        deployer.restart_pods()

def log_collect_handler(args, env):
    log_collector = LogCollector(env, args.upload)
    log_collector.collect()


def proxy_addr_handler(args, env):
    proxy_printer = PrintProxyAddr(env)
    proxy_printer.print()


def upload_custom_cert(args, env):
    custom_cert = UploadSecret(env, args)

    custom_cert.upload_json_secret_from_files(
        "cert-tls",
        (args.fullchain_pem, "fullchain.pem"),
        (args.privkey_pem, "privkey.pem"),
    )
    
    env.logger.info("Upload custom certificate to secret manager has been done")


def download_handler(args: argparse.Namespace, env: Env):
    downloader = Download(env, args)
    downloader.download_secret(args.secret)


if __name__ == "__main__":
    satori_parser = argparse.ArgumentParser(prog="python3 satori.py")
    deploy_sub_parser = satori_parser.add_subparsers()

    # deployment
    deploy_parser = deploy_sub_parser.add_parser(
        "deploy", description="Deploy management"
    )
    deploy_parser.set_defaults(func=deploy_handler)
    deploy_parser.add_argument(
        "--yes",
        help="Assume yes when asked",
        action="store_const",
        default=False,
        const=True,
        required=False,
    )
    deploy_parser.add_argument(
        "--wait",
        help="wait for helm to finish deployment before exit",
        action="store_const",
        default=False,
        const=True,
        required=False,
    )
    deploy_parser.add_argument(
        "--debug",
        help="Pass to helm debug flag",
        action="store_const",
        default=False,
        const=True,
        required=False,
    )
    deploy_parser.add_argument(
        "--atomic",
        help="wait + rollback",
        action="store_const",
        default=False,
        const=True,
        required=False,
    )
    deploy_parser.add_argument(
        "--timeout",
        nargs="?",
        help="Timeout to wait for deployment until it is marked as failed",
        default="3h30m",
        type=str,
        required=False,
    )
    deploy_parser.add_argument(
        "--dac_manager_no_cluster_role",
        nargs="?",
        help="Internal use by auto upgrade of dac-manager",
        default=False,
        const=True,
        required=False,
    )
    deploy_parser.add_argument(
        "--dac_installer",
        nargs="?",
        help="Internal use by dac-installer",
        default=True,
        const=True,
        required=False,
    )
    deploy_parser.add_argument(
        "--no_client_tls",
        nargs="?",
        help="custom-certificate, cert-tls certificate won't be created",
        default=False,
        const=True,
        required=False,
    )
    deploy_parser.add_argument(
        "--bootstrap_otp",
        type=str,
        help="One time URL to retrieve GCP service account",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--sa_id",
        type=str,
        help="service account ID to retrieve GCP service account",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--sa_key",
        type=str,
        help="service account key to retrieve GCP service account",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--sa_secret",
        type=str,
        help="service account secret name to retrieve GCP service account",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--dac_id",
        type=str,
        help="DAC ID",
        required=False,
        default="",
    )
    deploy_parser.add_argument(
        "--mgmtApiHost",
        type=str,
        help="management API hostname",
        required=False,
        default="app.satoricyber.com",
    )

    secret_rotation_parser = deploy_sub_parser.add_parser("rotate", description="Rotate secrets")
    secret_rotation_parser.set_defaults(func=secret_rotation_handler)

    # logs
    log_parser = deploy_sub_parser.add_parser("logs", description="Log collection")
    log_parser.set_defaults(func=log_collect_handler)
    log_parser.add_argument(
        "--upload",
        help="Upload the logs to Satori Customer Success",
        action="store_const",
        default=False,
        const=True,
        required=False,
    )

    # show proxy
    proxy_parser = deploy_sub_parser.add_parser(
        "proxyurl", description="Print the proxy address"
    )
    proxy_parser.set_defaults(func=proxy_addr_handler)

    # custom certificate
    cert_parser = deploy_sub_parser.add_parser(
        "upload-custom-cert",
        description="upload custom certificate to google secrect manager",
    )
    cert_parser.set_defaults(func=upload_custom_cert)
    cert_parser.add_argument(
        "--fullchain-pem",
        help="Path to the custom certificate fullchain pem file",
        default=False,
        required=True,
    )
    cert_parser.add_argument(
        "--privkey-pem",
        help="Path to the custom certificate private key pem file",
        default=False,
        required=True,
    )
    cert_parser.add_argument(
        "--bootstrap_otp",
        type=str,
        help="One time URL to retrieve GCP service account",
        required=False,
        default="",
    )
    cert_parser.add_argument(
        "--sa_id",
        type=str,
        help="service account ID to retrieve GCP service account",
        required=False,
        default="",
    )
    cert_parser.add_argument(
        "--sa_key",
        type=str,
        help="service account key to retrieve GCP service account",
        required=False,
        default="",
    )
    cert_parser.add_argument(
        "--sa_secret",
        type=str,
        help="service account secret name to retrieve GCP service account",
        required=False,
        default="",
    )
    cert_parser.add_argument(
        "--dac_id",
        type=str,
        help="DAC ID",
        required=False,
        default="",
    )
    cert_parser.add_argument(
        "--mgmtApiHost",
        type=str,
        help="management API hostname",
        required=False,
        default="app.satoricyber.com",
    )

    # download secret
    download_parser = deploy_sub_parser.add_parser("download", description="Download secret")
    download_parser.set_defaults(func=download_handler)
    download_parser.add_argument(
        "--secret",
        help="Download specific secret from GCP secret manager",
        default=False,
        required=True,
    )
    download_parser.add_argument(
        "--bootstrap_otp",
        type=str,
        help="One time URL to retrieve GCP service account",
        required=False,
        default="",
    )
    download_parser.add_argument(
        "--sa_id",
        type=str,
        help="service account ID to retrieve GCP service account",
        required=False,
        default="",
    )
    download_parser.add_argument(
        "--sa_key",
        type=str,
        help="service account key to retrieve GCP service account",
        required=False,
        default="",
    )
    download_parser.add_argument(
        "--sa_secret",
        type=str,
        help="service account secret name to retrieve GCP service account",
        required=False,
        default="",
    )
    download_parser.add_argument(
        "--dac_id",
        type=str,
        help="DAC ID",
        required=False,
        default="",
    )
    download_parser.add_argument(
        "--mgmtApiHost",
        type=str,
        help="management API hostname",
        required=False,
        default="app.satoricyber.com",
    )

    # parse and handle
    args = satori_parser.parse_args()
    try:
        args.no_client_tls = bool(strtobool(os.environ["NO_CLIENT_TLS"]))
    except KeyError:
        pass

    dac_installer = getattr(args, "dac_installer", True)
    env = Env(dac_installer)
    args.func(args, env)
