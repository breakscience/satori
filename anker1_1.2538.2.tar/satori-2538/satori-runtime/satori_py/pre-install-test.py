import base64
import os
import logging
import subprocess
import sys



class SatoriPreInstallTester:
    def __init__(self, env):
        self.env: Env = env
        self.logger: logging.Logger = env.logger
   
    def pre_install_test(self):
        if not self.verify_current_dac_name_correctness():        
           self.logger.error("Error. The installed DAC name doesn't equal to the new one, Aborting deployment and exiting.")
           sys.exit(10)

    # This function compares old and new secrets to make sure thay are related to the same backend. Intended to prevent accidental DAC overwriting.
    def verify_current_dac_name_correctness(self):
        secret_id="project-id-stamp"
        self.logger.info("Check if Current DAC deployment has same DAC to prevent accidental DAC overwriting.")
        new_project_id=os.environ.get("gcpBackendProjectId","None")
        self.logger.info("New project_id is %s", new_project_id)
        self.logger.info("Get Current project_id from kubernetes secret: %s",secret_id)
        response: subprocess.CompletedProcess = self.env.cmd("kubectl get secret -n %s %s -o=jsonpath='{.data.%s}'" % (self.env.k8s_namespace,secret_id,secret_id), can_fail=True)
        if response.returncode == 1:
            self.logger.info("Can't find Current secret: %s. Probably this is first deployment. Creating new secret",secret_id)
            self.env.cmd("kubectl create secret generic %s --from-literal=%s=%s -n %s"% (secret_id, secret_id, new_project_id, self.env.k8s_namespace))
            self.logger.info("New secret %s created", secret_id)
        else:
          current_project_id=base64.b64decode(response.stdout).decode('utf-8')
          self.logger.info("Current project_id from secret %s is %s",secret_id, current_project_id)
          if current_project_id==new_project_id:
            self.logger.info("Current project_id from secret %s equals to the new project_id. We can continue.",secret_id)
          else:
            self.logger.info("Current project_id from secret %s DOES NOT equals to the new project_id. Return False.",secret_id)
            return False  
              
        return True
    

class Env:
    def __init__(self):
        self.logger = logging.getLogger("satori")
        self.logger.setLevel(logging.DEBUG)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
        self.logger.addHandler(ch)
        self.k8s_namespace = os.environ.get("POD_NAMESPACE", "satori-runtime")


    def cmd(
        self,
        command,
        can_fail=False,
        input=None,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ):
        if not isinstance(command, list):
            command = command.split(" ")
        res = subprocess.run(command, stdout=stdout, stderr=stderr, input=input)

        if res.returncode != 0:
            # If the out streams are console, decode them to string for printing to the log
            if stdout == subprocess.PIPE:
                stdout = res.stdout.decode("utf-8")
            if stderr == subprocess.PIPE:
                stderr = res.stderr.decode("utf-8")
            if can_fail:
                self.logger.debug(
                    "Command '%s' returned %d, exiting:\n%s\n%s",
                    " ".join(command),
                    res.returncode,
                    stdout,
                    stderr,
                )
            else:
                self.logger.error(
                    "Command '%s' returned %d, exiting:\n%s\n%s",
                    " ".join(command),
                    res.returncode,
                    stdout,
                    stderr,
                )
                sys.exit(res.returncode)
        else:
            self.logger.debug(
                "Command '%s' finished can_fail=%s rc=%d:",
                " ".join(command),
                can_fail,
                res.returncode,
            )

        return res




if __name__ == "__main__":
    env = Env()
    satori_pre_install_tester = SatoriPreInstallTester(env)
    satori_pre_install_tester.pre_install_test()
